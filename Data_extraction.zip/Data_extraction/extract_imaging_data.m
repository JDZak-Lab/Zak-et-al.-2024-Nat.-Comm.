function[imaging_struct] = extract_imaging_data(frame_rate,do_registration)

%% Script to batch process a folder containing one imaging field of view
%can be modified to process several folders by looping with index of
%directories

if do_registration == 1
[stack_edges,directory] = combined_downsampled_2P([300 300]); %combine individual trial stacks into a larger singular stack, image binning optional
NRMCRE(directory);                                 %register and denoise larger stack using NoRMCORRE
split_stack(stack_edges,directory);                %split denoised/registered stack into individual trials for easy analysis
end

%%
if do_registration == 1
    [directory,CNM,options] = run_CNMF(directory);                   %runs class version of CNMF and extracts background subtracted components
else
    [directory,CNM,options] = run_CNMF();
end
assignin('base','CNM',CNM);
df_data = CNM.C_df;
Cn =  correlation_image_max(CNM.Y);

original_contours = figure;
figure
[~,json_file] = plot_contours(CNM.A,Cn,options,1); % contour plot of spatial footprints


[odor_index,stack_edges] = get_trial_info(directory);  %gets trialxodor index and frame index for trials
[open_frame,open_close,frames_open,solenoid_data] = align_solenoid(directory,frame_rate);
[ROI_cell,ROI_mat] = get_traces(df_data,odor_index,stack_edges,open_frame);  %sorts CNMF data into individual trials and odors
[total_peaks,respiration_filtered] = get_respiration(directory,open_close);

[imaging_struct] = make_imaging_struct(ROI_cell,ROI_mat,odor_index,respiration_filtered,solenoid_data);
[imaging_struct] = add_coordinates(imaging_struct,json_file);
imaging_struct.correlation_image = Cn;
imaging_struct.frame_rate = frame_rate;
imaging_struct.odor_index = odor_index;

open_frame_min = min(open_frame);
odor_on_off(1) = open_frame_min;
odor_on_off(2) = open_frame_min + frames_open;
imaging_struct.odor_on_off_frames = odor_on_off;

imaging_struct = variability_adjustment(imaging_struct); % adjusts for correlated variability across trials

imaging_struct.respiration_peaks = total_peaks;

imaging_struct.CNM = struct(CNM);
imaging_struct.directory = directory;
imaging_struct.date_extracted = datetime('now');

f = filesep; % save the struct in the selected directory
file_divisions = strsplit(directory,f);
struct_file_name = [file_divisions{end-1},'_',file_divisions{end-2},'_','struct.mat'];
save([directory,f,struct_file_name],'imaging_struct','-v7.3');

end