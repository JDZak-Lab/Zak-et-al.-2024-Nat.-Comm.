function [open_frame,open_close,frames_open,solenoid_data] = align_solenoid(directory,frame_rate)
%align_solenoid finds the nearest fram that the odor solenoid opens for
%each image file using an accompanying .data file

f = filesep;
% DataFiles = dir(strcat(directory,f,'data_files',f,'*.data'));
% addpath(strcat(directory,f,'data_files'));

to_delete = strcat(f,'combined movies');
directory = erase(directory,to_delete);
DataFiles = dir(strcat(directory,f,'*.data'));
addpath(directory);

filenames_data = {DataFiles.name}';
filenames_data = sort_nat(filenames_data); %sorts so that files are in order of odors 0,1,2 etc.
numfiles_data = length(DataFiles); 

%%

for i = 1:numfiles_data
    solenoid=fopen(filenames_data{i});
    solenoid_data_current=fread(solenoid,'double','b');
    solenoid_channel = solenoid_data_current((3*(length(solenoid_data_current))/4)+1:end);
    
    solenoid_data{i} = solenoid_channel;
    
    open_value = 10*std(solenoid_channel(1:2000));
    threshold_value = mean(solenoid_channel(1:2000)) + open_value;
    
    open_index = find(solenoid_channel>threshold_value,1);
    close_value = find(solenoid_channel(open_index:end) < threshold_value,1);
    close_index = open_index+close_value;
    open_close(i,1) = open_index;
    open_close(i,2) = close_index;
        
    open_close_all(i,:) = round((open_close(i,:)/1000)*frame_rate);
    open_frame(i) = open_close_all(i,1);

    fclose('all');
    
end

    open_close_frames = min(open_close_all);
    frames_open = open_close_frames(2)-open_close_frames(1);

for i = 1:numfiles_data
    sol_length(i) = length(solenoid_data{i});
end
min_sol_length = min(sol_length);
sol_diff = sol_length - min_sol_length;
for i = 1:numfiles_data
    solenoid_data{i}(1:sol_diff(i)) = [];
end

end

