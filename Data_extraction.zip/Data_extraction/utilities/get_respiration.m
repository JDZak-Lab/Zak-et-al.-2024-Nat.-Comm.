function [total_peaks,respiration_filtered] = get_respiration(directory,open_close)

%finds the number of inhalations during the odor period of each trial
%open_close is the frames that the solenoid opens and closes


f = filesep;
% DataFiles = dir(strcat(directory,f,'*.data'));

to_delete = strcat(f,'combined movies');
directory = erase(directory,to_delete);
DataFiles = dir(strcat(directory,f,'*.data'));
addpath(directory);

filenames_data = {DataFiles.name}';
filenames_data = sort_nat(filenames_data); %sorts so that files are in order of odors 0,1,2 etc.
numfiles_data = length(DataFiles); 

%%
windowSize = 100; 
b = (1/windowSize)*ones(1,windowSize);
a = 1;
for i = 1:numfiles_data
    respiration = fopen(filenames_data{i});
    respiration_data = fread(respiration,'double','b');
    respiration_channel = respiration_data((1*(length(respiration_data))/4)+1:(2*(length(respiration_data))/4));
    respiration_filtered{i} = filtfilt(b,a,respiration_channel);
    t{i} = respiration_channel;
    x_data = (0:1:length(respiration_filtered{i})-1)';
    [~,locs] = findpeaks(respiration_filtered{i},x_data,'MinPeakDistance',100,'MinPeakProminence',0.2);
    [ind,~] = find(locs > open_close(i,1) & locs < open_close(i,2));
    total_peaks(i) = length(ind);
    fclose('all');
end

for i = 1:numfiles_data
    resp_length(i) = length(respiration_filtered{i});
end
    min_resp_length = min(resp_length);
    resp_diff = resp_length - min_resp_length;
    
for i = 1:numfiles_data
    respiration_filtered{i}(1:resp_diff(i)) = [];
    respiration_filtered{i} = detrend(respiration_filtered{i});
    respiration_filtered{i} = respiration_filtered{i} - nanmean(respiration_filtered{i});
end

    
end