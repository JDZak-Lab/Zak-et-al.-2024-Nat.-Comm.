function[stack_edges,output_directory] = combined_downsampled_WF(image_size)
%image size is [y x] where y is pixel row number and x is column number 


if nargin == 0
    image_size = [150 150];
end

%% Get directory with files, create new folder, sort existing files by order
% directory = pwd;
f = filesep;
directory = uigetdir('I:\Data\2P data\OE Imaging');
addpath(directory);

folder_name_to_save = 'combined movies';
mkdir(directory,folder_name_to_save);
file_divisions = strsplit(directory,f);

output_directory = strcat(directory,f,folder_name_to_save);

f = filesep;
TiffFiles = dir(strcat(directory,f,'*G.tiff')); %make sure tif vs tiff is correct
filenames_tiff = {TiffFiles.name}';
filenames_tiff = sort_nat(filenames_tiff); %sorts so that files are in order of odors 0,1,2 etc.
numfiles_tiff = length(TiffFiles);    %determines the number of fimes being imported


%% Load individual stacks and resize images
for i = 1:numfiles_tiff
    file_string = strcat(directory,f,filenames_tiff{i});
    k = strfind(file_string,'.tiff');
        if k > 0
            FileTif=filenames_tiff{i};
             InfoImage=imfinfo(FileTif);
             mImage=InfoImage(1).Width;
             nImage=InfoImage(1).Height;
             NumberImages(i) = length(InfoImage);
             FinalImage = zeros(nImage,mImage,NumberImages(i),'uint16');

             TifLink = Tiff(FileTif, 'r');
                 for ii=1:NumberImages(i)
                    TifLink.setDirectory(ii);
                    FinalImage(:,:,ii) = TifLink.read();
                    BinnedImage(:,:,ii) = imresize(FinalImage(:,:,ii),image_size);
                 end
            TifLink.close();
        end
    all_stacks{i} = BinnedImage;
   clear BinnedImage;
end

%% Save combined stack as a single file
path_name_to_save = strcat(directory,f,folder_name_to_save);
parameters = strsplit(directory,f);
file_name_to_save = strcat(parameters{end-1},'_',parameters{end},'.tiff');


for i = 1:numfiles_tiff
    for t = 1:size(all_stacks{i},3)
        if i  == 1 && t == 1
            imwrite(all_stacks{i}(:,:,t),fullfile(path_name_to_save,file_name_to_save));
        else
            imwrite(all_stacks{i}(:,:,t),fullfile(path_name_to_save,file_name_to_save),'WriteMode','append');
        end
    end
end


 stack_edges(1) = NumberImages(1);
for i = 2:length(NumberImages)
    stack_edges(i) = stack_edges(i-1)+NumberImages(i);
end
stack_file_name = [file_divisions{end},'_',file_divisions{end-1},'_','stack_edges.mat'];
save([output_directory,f,stack_file_name],'stack_edges'); 


end