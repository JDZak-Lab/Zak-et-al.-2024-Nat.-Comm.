function[odor_index,stack_edges] = get_trial_info(directory)
f = filesep;
info_directory = erase(directory,'/combined movies');

addpath(directory);
addpath(info_directory);
info_files_info = dir(strcat(info_directory,f,'*info*'));
info_file = importdata(info_files_info(end).name);
odor_file = info_file.data(:,1:16);

odor_index = odor_indexing(odor_file);
%%
Mat_Files=dir(strcat(directory,f,'*mat*')); 
filenames_Mat = {Mat_Files.name}';
for i = 1:size(filenames_Mat,1)
    tf(i) = contains(filenames_Mat{i},'stack_edges');
end
files_to_load = find(tf>0);
load(Mat_Files(files_to_load).name);

end

