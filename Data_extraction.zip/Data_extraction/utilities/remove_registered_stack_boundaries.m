function[trimmed_stack] = remove_registered_stack_boundaries(stack,tolerance)
%%Removes boundaries of zero values from registered image to keep only
%%image portion with data in all frames.

%inputs:
%stack = 3D image stack of pre-registered images
%tolarance = percentage of frames a boundary limit can occur. Typical 0.5-1


all_rows = [];
all_columns = [];
%% Define boundary of every frame in the stack
for i = 1:size(stack,3)             %find all rows and columns that are full zeros to define frame shift boundaries
current_plane = stack(:,:,i);
vert_sum = sum(current_plane,2);
horz_sum = sum(current_plane,1);

empty_rows = find(vert_sum==0);
empty_columns = find(horz_sum==0);

all_rows = cat(1,all_rows,empty_rows);
all_columns = cat(2,all_columns,empty_columns);
end

%% Find boundaries that occur on only a single or few frames.

to_delete_rows = unique(all_rows);
to_delete_columns = unique(all_columns);

row_occurance = [];
for i = 1:length(to_delete_rows)          %find the number of frames each boundry occured
    F_row = find(to_delete_rows(i)==all_rows);
    row_occurance(i) = length(F_row);
end

column_occurance = [];
for i = 1:length(to_delete_columns) 
    F_column = find(to_delete_columns(i)==all_columns);
    column_occurance(i) = length(F_column); 
end

Threshold = (tolerance/100)*size(stack,3);  %fraction of frames that a boundry can occur before it is removed

rows_to_keep = find(row_occurance < Threshold); %remove rows and columns that occured less that the threshold fraction of frames
to_delete_rows(rows_to_keep) = [];

columns_to_keep = find(column_occurance < Threshold);
to_delete_columns(columns_to_keep) = [];

stack(to_delete_rows,:,:) = [];      %remove fequently occuring boundaries to trim image stack
stack(:,to_delete_columns,:) = [];

trimmed_stack = stack;
end

