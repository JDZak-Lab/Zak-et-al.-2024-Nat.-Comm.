function[new_odor_index] = sort_odor_index_antagonism(odor_index)

%% make index of sorted odors
sorted_odors{1} = [];
sorted_odors{2} = 8;
sorted_odors{3} = 7;
sorted_odors{4} = 6;
sorted_odors{5} = 5;
sorted_odors{6} = 4;
sorted_odors{7} = [3 4];
sorted_odors{8} = [2 3 4];
sorted_odors{9} = [1 2 3 4];
sorted_odors{10} = 16;
sorted_odors{11} = 15;
sorted_odors{12} = 14;
sorted_odors{13} = 13;
sorted_odors{14} = 12;
sorted_odors{15} = [11 12];
sorted_odors{16} = [10 11 12];
sorted_odors{17} = [9 10 11 12];
sorted_odors{18} = [8 16];
sorted_odors{19} = [7 15];
sorted_odors{20} = [6 14];
sorted_odors{21} = [5 13];
sorted_odors{22} = [4 12];
sorted_odors{23} = [3 4 11 12];
sorted_odors{24} = [2 3 4 10 11 12];
sorted_odors{25} = [1 2 3 4 9 10 11 12];

%% find blank odor
for i = 1:size(odor_index,1)
    tf(i) = isempty(odor_index{i,2});
end
position = find(tf==1);
new_odor_index(1,:) = odor_index(position,:);

%% build new odor index form sorted list

for i = 2:size(sorted_odors,2)
    for j = 1:size(odor_index,1)
    tf(j) = isequal(odor_index{j,2},sorted_odors{i});
    end
    position = find(tf==1);
    new_odor_index(i,:) = odor_index(position,:);    
end


end