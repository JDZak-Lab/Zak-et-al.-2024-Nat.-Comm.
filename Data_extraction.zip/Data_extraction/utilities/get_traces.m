function[ROI_cell,ROI_mat] = get_traces(df_data,odor_index,stack_edges,open_frame)

baseline_frames = min(open_frame);
num_ROIs = size(df_data,1);
num_trials = size(stack_edges,2);
num_odors = size(odor_index,1);

for t = 1:num_ROIs
    current_ROI = df_data(t,:);
    baseline = nanmean(current_ROI(1:baseline_frames));
    current_ROI = current_ROI - baseline;
    data_cell{t,1} = current_ROI(1:stack_edges(1));

        for i = 2:num_trials
            current_trace = current_ROI(stack_edges(i-1)+1:stack_edges(i));
            baseline = nanmean(current_trace(1:baseline_frames));
            data_cell{t,i} = current_trace-baseline;
        end
end

%% use solenoid data to align open frame

for i = 1:num_trials
    if open_frame(i) > baseline_frames
        frame_diff = open_frame(i)-baseline_frames;
        for j = 1:num_ROIs
        data_cell{j,i}(1:frame_diff) = [];
        end
    end
end

%% adjust trial lengths to match
for j = 1:num_trials
    trace_lengths(j) = length(data_cell{1,j});
end

min_length = min(trace_lengths);

for i = 1:num_ROIs
    for j = 1:num_trials
        if length(data_cell{i,j}) > min_length
            data_cell{i,j}(min_length+1:end)=[];
        end
    end
end

for t = 1:num_ROIs
    for i = 1:num_odors
        for j = 1:size(odor_index{i,1},2)
            ROI_cell{t,i}(:,j) = data_cell{t,odor_index{i,1}(j)};
        end
        if size(ROI_cell{t,i},2)>1
        ROI_mat(t,i,:) = nanmean(ROI_cell{t,i},2);
        else
        ROI_mat(t,i,:) = ROI_cell{t,i};  
        end
    end
end


end


