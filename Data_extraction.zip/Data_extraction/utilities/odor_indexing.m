function[index] = odor_indexing(odor_file)


for i = 1:size(odor_file,1)
    odor_index{i} = find(odor_file(i,:) == 1);
end


for j = 1:size(odor_index,2)
    for i = 1:size(odor_index,2)
        tf = isequal(odor_index{j},odor_index{i});
        vec_equal(i) = tf;
        vec_index{j} = find(vec_equal == 1);
    end
end



for i = 1:size(vec_index,2)
    for j = vec_index{i}(2:end)
        vec_index{j} = [];
    end
end
         
unique_odors = vec_index(~cellfun('isempty',vec_index)); 

for i = 1:size(unique_odors,2)
    odor_content = unique_odors{1,i}(1);
    unique_odors{2,i} = odor_index{odor_content};
    index = unique_odors';
end
end
    

    
    
    
    
    
    
    
    
    

