function [threshold] = roc_threshold(values_matrix)

%% values_matrix is a response x odor x repeat matrix. Response is a single value ie. vals_adjusted_var_mean

mean_mat = nanmean(values_matrix,3);
blank_vector = mean_mat(:,1)';
response_vector = reshape(mean_mat(:,2:end),1,size(mean_mat(:,2:end),1)*size(mean_mat(:,2:end),2));


%Replicate no_odor_vector so it is the same length as response_vector
%(takes care of cases where unequal number of repeats)
num_rep_floor = floor(length(response_vector)/length(blank_vector));
num_rep_remainder = mod(length(response_vector),length(blank_vector));

% no_odor_vector = repmat(no_odor_vector,[1 num_rep_floor]);
% no_odor_vector = [no_odor_vector no_odor_vector(1:num_rep_remainder)];
% no_odor_vector = reshape(no_odor_vector,[size(no_odor_vector,1)*size(no_odor_vector,2)],1);

no_odor_vector = repmat(blank_vector,1,num_rep_floor);
no_odor_vector = cat(2,no_odor_vector, no_odor_vector(1:num_rep_remainder));

%%

max1 = max(response_vector);
max2 = max(no_odor_vector);
max_threshold = max(max1,max2);

increment = 0.001;
num_thresholds = max_threshold/increment;
current_threshold = 0;
false_alarm_vector = zeros(round(num_thresholds),1); %Vector saving the number of false alarms for each threshold
hits_vector = zeros(round(num_thresholds),1); %Vector saving the number of hits for each threshold
thresholds = zeros(round(num_thresholds),1);

for i = 1:round(num_thresholds)
    current_threshold = current_threshold + increment;
    thresholds(i) = current_threshold;
    num_false_alarms = length(find(no_odor_vector>current_threshold));
    false_alarm_vector(i) = num_false_alarms;
    num_hits = length(find(response_vector>current_threshold));
    hits_vector(i) = num_hits;
end
    

x = 0:1:max(false_alarm_vector);
y = 10*x;

tenpercent_line = y;
% figure;
% plot(false_alarm_vector,hits_vector)
% hold on
% plot(tenpercent_line)


%Pick the threshold that falls on the 10% line (100 hits for every 10 false alarms) and in case of multiple interesections, pick the one that gives you the highest number of hits 

%Find intersections
[x0,y0] = intersections(false_alarm_vector,hits_vector,x,y);
index = find(y0==max(y0));
% hold on
% scatter(x0,y0);
% title('ROC curve');

%Find the closest point on the ROC curve that corresponds to the intersection
value = y0(index);
[~, closest_value_index] = min(abs(hits_vector - value(1)));
closest_roc_point = hits_vector(closest_value_index);
roc_index = min(find(hits_vector==closest_roc_point)); %In case there are two equidistant points, take the min to get a smaller threshold and more responses
threshold = thresholds(roc_index);

end








