function[imaging_struct] = add_coordinates(imaging_struct,json_file)

for i = 1:size(json_file,1)
    imaging_struct.activity_data(i).coord = json_file(i).coordinates;
    imaging_struct.activity_data(i).centroid = json_file(i).centroid;
end

end