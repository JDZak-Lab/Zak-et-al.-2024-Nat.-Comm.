function[imaging_struct] = make_imaging_struct(ROI_cell,ROI_mat,odor_index,respiration_filtered,solenoid_data)

num_odors = size(ROI_cell,2);
num_rois = size(ROI_cell,1);

for i = 1:num_odors
    reps(i) = size(ROI_cell{1,i},2);
end

max_reps = max(reps);
for i = 1:num_odors
    for j = 1:num_rois
        if reps(i) < max_reps
            length_nan = size(ROI_cell{j,i},1);
            ROI_cell{j,i}(:,reps(i)+1:max_reps) = NaN;
        end
    end
end

for i = 1:num_odors
    for j = 1:num_rois
        for k = 1:max_reps
            imaging_struct.activity_data(j).dff{k,i} = ROI_cell{j,i}(:,k)';
        end
    end
end

for t = 1:num_rois
    for i = 1:size(odor_index,1)
    trial_index = odor_index{i};
    num_repeats = size(trial_index,2);
        for k = 1:num_repeats
            for j = trial_index(k)
                imaging_struct.activity_data(t).respiration{k,i} = respiration_filtered{j};
                imaging_struct.activity_data(t).solenoid{k,i} = solenoid_data{j};
            end
        end
    end
end

imaging_struct.dff_data = ROI_cell;
imaging_struct.ROI_matrix = ROI_mat;

end