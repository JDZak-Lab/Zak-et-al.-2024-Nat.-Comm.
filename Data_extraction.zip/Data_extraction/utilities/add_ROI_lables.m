function[imaging_struct] = add_ROI_lables(imaging_struct,to_delete_mean,to_delete_peaks)

for i = 1:size(imaging_struct.activity_data,2)
    imaging_struct.activity_data(i).mean_adjusted_components = 'real';
    imaging_struct.activity_data(i).peaks_adjusted_components = 'real';
end

for i = 1:length(to_delete_mean)
imaging_struct.activity_data(to_delete_mean(i)).mean_adjusted_components = 'discarded';
end

for i = 1:length(to_delete_peaks)
imaging_struct.activity_data(to_delete_peaks(i)).peaks_adjusted_components = 'discarded';
end

end