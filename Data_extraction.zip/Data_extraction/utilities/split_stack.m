function[] = split_stack(stack_edges,directory)

f = filesep;
if nargin == 1
    directory = uigetdir('I:\Data\2P data\OE Imaging');
end

addpath(directory);
TiffFiles = dir(strcat(directory,f,'*nr.tif')); %make sure tif vs tiff is correct
filenames_tiff = TiffFiles.name;

folder_name_to_save = 'split movies';
mkdir(directory,folder_name_to_save);
output_directory = strcat(directory,f,folder_name_to_save);

file_string = strcat(directory,f,filenames_tiff);

FileTif=file_string;
InfoImage=imfinfo(FileTif);
mImage=InfoImage(1).Width;
nImage=InfoImage(1).Height;

file_divisions = strsplit(filenames_tiff,'_nr');

           
NumberImages(1) = stack_edges(1);
for i = 2:length(stack_edges)
    NumberImages(i) = stack_edges(i)- stack_edges(i-1); 
end

for i = 1:length(stack_edges)
     FinalImage = zeros(nImage,mImage,NumberImages(i),'uint16');
     TifLink = Tiff(FileTif, 'r');
     
      trial = num2str(i-1);
      file_name_final = strcat('nr_',file_divisions{1},'_T',trial,'_G.tiff');
     
     if i == 1
        for ii=1:stack_edges(i)
            TifLink.setDirectory(ii);
            FinalImage(:,:,ii) = TifLink.read();
        end
      TifLink.close();
        for t = 1:NumberImages(i)
            if t == 1
            imwrite(FinalImage(:,:,t),fullfile(output_directory,file_name_final));
            else
            imwrite(FinalImage(:,:,t),fullfile(output_directory,file_name_final),'WriteMode','append');
            end
         end            
     else
         for ii=(stack_edges(i-1)+1):stack_edges(i)
             TifLink.setDirectory(ii);
             FinalImage(:,:,ii - stack_edges(i-1)) = TifLink.read();
         end
       TifLink.close();
        for t = 1:NumberImages(i)
            if t == 1
            imwrite(FinalImage(:,:,t),fullfile(output_directory,file_name_final));
            else
            imwrite(FinalImage(:,:,t),fullfile(output_directory,file_name_final),'WriteMode','append');
            end
        end
     end
end

end