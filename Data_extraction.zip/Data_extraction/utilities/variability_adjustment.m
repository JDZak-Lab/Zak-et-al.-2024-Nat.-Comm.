function[odor_struct] = variability_adjustment(odor_struct)
%% extracts mean and max response for each trial and adjusts for correlated variability 
%note that the mean response is dictated by the solenoid closing frame. Add
%frams to extrend out if necessary

%note2: this data is pulled from dff data that is adjusted for bleaching
%but not background subtracted. 

num_odors = size(odor_struct.activity_data(1).dff,2);
num_repeats = size(odor_struct.activity_data(1).dff,1);
num_rois = length(odor_struct.activity_data);
odor_on_off = odor_struct.odor_on_off_frames;
frame_rate = odor_struct.frame_rate;
odor_on_off(2) = odor_on_off(1)+5*frame_rate; % comment to include only solenoid open time

for k = 1:num_odors
    for i = 1:num_rois
        for j = 1:num_repeats
            tf = isempty(odor_struct.activity_data(i).dff{j,k});
            if tf == 0
                y_data_mean(i,j) = nanmean(odor_struct.activity_data(i).dff{j,k}...
                    (odor_on_off(1):odor_on_off(2))); %finds mean response for each trial
                
                current_trace = odor_struct.activity_data(i).dff{j,k}...
                    (odor_on_off(1):end); %finds max response for each trial
               
                M = movmean(current_trace,5,'omitnan');
                
                y_data_max(i,j) = max(M);
            else
                y_data_mean(i,j) = NaN;
                
                y_data_max(i,j) = NaN;
            end
        end
      all_responses = cell2mat(odor_struct.activity_data(i).dff(:,k)'); %get all trials from the same roi for odor k
      mean_response_each = nanmean(all_responses(:,odor_on_off(1):odor_on_off(2)),2); %find the mean response for each trail
      x_data_mean(i,:) = nanmean(mean_response_each); %find mean of the mean responses
      
      max_response_each = max(all_responses(:,odor_on_off(1):end),[],2); %find the max response for each trial
      x_data_max(i,:) = nanmean(max_response_each); %find the mean of the maximum responses
    end
    
      x_mean = repmat(x_data_mean,num_repeats,1); %make matricies with mean values repeating to plot against individual trals
      x_max = repmat(x_data_max,num_repeats,1);
      
      y_mean = reshape(y_data_mean,num_repeats*num_rois,1); %reshape to a single vector maintaining order 
      y_max = reshape(y_data_max,num_repeats*num_rois,1);
      
      x_mean = x_mean(~isnan(y_mean)); %remove any nan trials from the new vector that correspond to missing individual data
      x_max = x_max(~isnan(y_max));
      
      y_mean = y_mean(~isnan(y_mean)); %remove nan values from individual trials
      y_max = y_max(~isnan(y_max));
      
      p_mean = polyfit(x_mean,y_mean,1); %fit a first degree polynomial (linear) to the mean plotted against individual trials
      p_max = polyfit(x_max,y_max,1);
      
%       f_mean = polyval(p_mean,x_mean); %can use to make plot 
%       f_max = polyval(p_max,x_max);


    for i  = 1:num_repeats %make linear fits to the data from each of the individual trials
        p_trial_mean = polyfit(x_data_mean,y_data_mean(:,i),1); 
        p_trial_max = polyfit(x_data_max,y_data_max(:,i),1); 
        
        f_trial_mean = polyval(p_trial_mean,x_data_mean); %get y values for from fit
        f_trial_max = polyval(p_trial_max,x_data_max);

        f_diff_mean(:,i) = polyval(p_mean,x_data_mean)-f_trial_mean; %find difference in the fit to the mean data and 
        f_diff_max(:,i) = polyval(p_max,x_data_max)-f_trial_max; %fit to the individual trials
        
        y_adjusted_mean(:,k,i) = y_data_mean(:,i)+f_diff_mean(:,i); %get new adjusted values for each of the  trails
        y_adjusted_max(:,k,i) = y_data_max(:,i)+f_diff_max(:,i);
    end

end    
    
for i = 1:num_rois %create new array that can be added to struct 
    for j = 1:num_odors
        for k = 1:num_repeats
        odor_struct.activity_data(i).mean_response_adjusted(k,j) = y_adjusted_mean(i,j,k); 
        odor_struct.activity_data(i).peak_response_adjusted(k,j) = y_adjusted_max(i,j,k);
        end
    end
end

% for c = 1:size(odor_struct.activity_data,2)
%     tf(c) = strcmp('background',odor_struct.activity_data(c).roi_type); %delete rois corresponding to background
% end
% del = find(tf==1);
% y_adjusted_mean(del,:,:)=[];
% y_adjusted_max(del,:,:)=[];
clear tf f i 

odor_struct.vals_adjusted_var_mean = y_adjusted_mean;
odor_struct.vals_adjusted_var_max = y_adjusted_max;


end















    
    