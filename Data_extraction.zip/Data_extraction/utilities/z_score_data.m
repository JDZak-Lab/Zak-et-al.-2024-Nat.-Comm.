function[imaging_struct] = z_score_data(imaging_struct)
%% Z-score dff data and get mean Z score and adjust for correlated varriability

odor_on = imaging_struct.odor_on_off_frames(1);

num_odors = size(imaging_struct.activity_data(1).dff,2);
num_repeats = size(imaging_struct.activity_data(1).dff,1);
num_rois = length(imaging_struct.activity_data);



for i = 1:num_rois
    for j = 1:num_repeats
        for k = 1:num_odors
            current_trace = imaging_struct.activity_data(i).dff{j,k};
            mean_baseline = nanmean(current_trace(1:odor_on));
            std_baseline = nanstd(current_trace(1:odor_on));
            z_score = (current_trace-mean_baseline)./std_baseline;
            
            imaging_struct.activity_data(i).z_scored{j,k} = z_score;
            imaging_struct.z_scored_data{i,k}(:,j) = z_score;
        end
    end
end


for i = 1:num_rois
    for j = 1:num_odors
        imaging_struct.z_score_matrix(i,j,:) = nanmean(imaging_struct.z_scored_data{i,j},2);
    end
end

end
