function[imaging_struct,to_delete_mean,to_delete_peaks] = remove_below_threshold_data(imaging_struct)

threshold = roc_threshold(imaging_struct.vals_adjusted_var_mean);
mean_mat = nanmean(imaging_struct.vals_adjusted_var_mean,3);


for i = 1:size(mean_mat,1)
    t = find(mean_mat(i,2:end)>threshold);
    e(i) = isempty(t);
end
to_delete_mean = find(e==1);
threshold_mean = imaging_struct.vals_adjusted_var_mean;
threshold_mean(to_delete_mean,:,:) = [];
imaging_struct.threshold_mean = threshold_mean;
ROI_matrix = imaging_struct.ROI_matrix;
ROI_matrix(to_delete_mean,:,:) = [];
imaging_struct.traces_mean_threshold = ROI_matrix;
imaging_struct.roc_threshold_mean = threshold;


threshold = roc_threshold(imaging_struct.vals_adjusted_var_max);
max_mat = nanmean(imaging_struct.vals_adjusted_var_max,3);


for i = 1:size(max_mat,1)
    t = find(max_mat(i,2:end)>threshold);
    e(i) = isempty(t);
end
to_delete_peaks = find(e==1);
threshold_peaks = imaging_struct.vals_adjusted_var_max;
threshold_peaks(to_delete_peaks,:,:) = [];
imaging_struct.threshold_peaks = threshold_peaks;
ROI_matrix = imaging_struct.ROI_matrix;
ROI_matrix(to_delete_peaks,:,:) = [];
imaging_struct.traces_peaks_threshold = ROI_matrix;
imaging_struct.roc_threshold_peaks = threshold;


end